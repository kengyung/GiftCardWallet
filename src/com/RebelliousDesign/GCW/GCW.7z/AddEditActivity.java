package com.RebelliousDesign.GCW;

import android.app.Activity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEditActivity extends Activity implements OnClickListener {
GiftCard currentCard = new GiftCard();	
	
String company, serial, notes;
double balance;
int expiry;


Button ok, cancel;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	final EditText companyInput, serialInput, notesInput, balanceInput, expiryInput;

    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
          	
    	
    	companyInput = (EditText) findViewById(R.id.companyNameInput);
    	serialInput = (EditText) findViewById(R.id.serialNumberInput);
    	notesInput = (EditText) findViewById(R.id.notesInput);
    	balanceInput = (EditText) findViewById(R.id.cardBalanceInput);
    	//expiryInput = (EditText) findViewById(R.id.companyNameInput);
    	
        ok = (Button) findViewById(R.id.okBtn);
        cancel = (Button) findViewById(R.id.cancelBtn);
        
        
        
        ok.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		//Toast.makeText(getApplicationContext(), "Ok was pressed", Toast.LENGTH_SHORT).show();
        		
        		if (companyInput.getText() != null || companyInput.getText().equals("")){
        			currentCard.setCompany(companyInput.getText().toString());
        			//company = companyInput.getText().toString();
        		}
        		
        		if (serialInput.getText() != null || serialInput.getText().equals("")){
        			currentCard.setSerial(serialInput.getText().toString());        			
        			//serial = serialInput.getText().toString();
        	}
        		if (notesInput.getText() != null || notesInput.getText().equals("")){
        			currentCard.setNotes(notesInput.getText().toString());
        			//notes = notesInput.getText().toString();
        	}
        		if (balanceInput.getText() != null || balanceInput.getText().equals("")){
        			currentCard.setBalance(Double.parseDouble(balanceInput.getText().toString()));
        			
        			//balance = Double.parseDouble(balanceInput.getText().toString());
        	}
        		
        		//company = companyInput.getText().toString();
        		//Toast.makeText(getApplicationContext(), "Company: " + company , Toast.LENGTH_SHORT).show();
        		
        		Toast.makeText(getApplicationContext(), "Company: " + currentCard.getCompany() + "\nSerial: " + currentCard.getSerial() +"\nNotes: " + currentCard.getNotes() + "\nBalance: " + Double.toString(currentCard.getBalance()), Toast.LENGTH_SHORT).show();
        		
        		
        	}
        }
        );
        
        cancel.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		Toast.makeText(getApplicationContext(), "Cancel was pressed", Toast.LENGTH_SHORT).show();	
        	}
        }
        );
        
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}


}