package com.RebelliousDesign.GCW;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class GiftCardAddEdit extends Activity {
	GiftCard currentCard = new GiftCard();
	private GiftCardDataSource gcDAO;
	
	String company, serial, notes;
	double balance;
	int expiry;
	
	Button ok, cancel;
	
	
	final int OK = 0;
	final int NOTOK = 1;

    public void onCreate(Bundle savedInstanceState) {
    	final EditText companyInput, serialInput, notesInput, balanceInput, expiryInput;
    	int RETURN_CODE = 1; //by default  not okay  

    	super.onCreate(savedInstanceState);
        setContentView(R.layout.add_edit_giftcard);
        
        gcDAO = new GiftCardDataSource(this);
        gcDAO.open();
          	
    	
    	companyInput = (EditText) findViewById(R.id.companyNameInput);
    	serialInput = (EditText) findViewById(R.id.serialNumberInput);
    	notesInput = (EditText) findViewById(R.id.notesInput);
    	balanceInput = (EditText) findViewById(R.id.cardBalanceInput);
    	//expiryInput = (EditText) findViewById(R.id.companyNameInput);
    	
        ok = (Button) findViewById(R.id.okBtn);
        cancel = (Button) findViewById(R.id.cancelBtn);
        
        
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
        		RETURN_CODE = NOTOK;
        		}
        // Get data via the key
        String id = extras.getString("id");
        if (id != null) {
        	// Do something with the data
        	Toast.makeText(getApplicationContext(), "Item #:" + id + " was touched.", Toast.LENGTH_SHORT).show();
        }
        
        
        ok.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		//Toast.makeText(getApplicationContext(), "Ok was pressed", Toast.LENGTH_SHORT).show();
        		
        		if (companyInput.getText() != null || companyInput.getText().equals("")){
        			currentCard.setCompany(companyInput.getText().toString());
        			//company = companyInput.getText().toString();
        		}
        		
        		if (serialInput.getText() != null || serialInput.getText().equals("")){
        			currentCard.setSerial(serialInput.getText().toString());        			
        			//serial = serialInput.getText().toString();
        	}
        		if (notesInput.getText() != null || notesInput.getText().equals("")){
        			currentCard.setNotes(notesInput.getText().toString());
        			//notes = notesInput.getText().toString();
        	}
        		if (balanceInput.getText() != null || balanceInput.getText().equals("")){
        			currentCard.setBalance(Double.parseDouble(balanceInput.getText().toString()));
        			
        			//balance = Double.parseDouble(balanceInput.getText().toString());
        	}
        		
        		//company = companyInput.getText().toString();
        		//Toast.makeText(getApplicationContext(), "Company: " + company , Toast.LENGTH_SHORT).show();
        		
        		Toast.makeText(getApplicationContext(), "Company: " + currentCard.getCompany() + "\nSerial: " + currentCard.getSerial() +"\nNotes: " + currentCard.getNotes() + "\nBalance: " + Double.toString(currentCard.getBalance()), Toast.LENGTH_SHORT).show();
        		
        		
        	}
        }
        );
        
        cancel.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		Toast.makeText(getApplicationContext(), "Cancel was pressed", Toast.LENGTH_SHORT).show();	
        	}
        }
        );
        
    }
    
}
