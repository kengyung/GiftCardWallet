package com.RebelliousDesign.GCW;
//see http://www.vogella.de/articles/AndroidSQLite/article.html#sqliteoverview_sqliteopenhelper
//Will need to move GiftCardDbAdapter over

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class GiftCardDataSource {

	// Database fields
	private SQLiteDatabase database;
	private GiftCardDbAdapter dbHelper;
	private String[] allColumns = new String[] {GiftCardDbAdapter.KEY_ROWID,
			GiftCardDbAdapter.KEY_COMPANY, GiftCardDbAdapter.KEY_SERIAL,
			GiftCardDbAdapter.KEY_EXPIRY, GiftCardDbAdapter.KEY_PHONE,
			GiftCardDbAdapter.KEY_BALANCE, GiftCardDbAdapter.KEY_NOTES};
	
	
	public GiftCardDataSource(Context ctx){
		dbHelper = new GiftCardDbAdapter(ctx);
	}
	
	public void open(){
		database = dbHelper.getWritableDatabase();
	}
	
	public void close(){
		dbHelper.close();
	}
	
	public long createGC(GiftCard gc){
		ContentValues values = new ContentValues();
		values.put(GiftCardDbAdapter.KEY_COMPANY, gc.getCompany());
		values.put(GiftCardDbAdapter.KEY_BALANCE, gc.getBalance());
		values.put(GiftCardDbAdapter.KEY_EXPIRY, gc.getExpiry());
		values.put(GiftCardDbAdapter.KEY_PHONE, gc.getPhone());
		values.put(GiftCardDbAdapter.KEY_SERIAL, gc.getSerial());
		values.put(GiftCardDbAdapter.KEY_NOTES, gc.getNotes());
		
		return database.insert(GiftCardDbAdapter.DATABASE_TABLE, null, values);
		
	}
	
	public void deleteGC(GiftCard gc){
		long id = gc.getID();
		
		database.delete(GiftCardDbAdapter.DATABASE_TABLE, GiftCardDbAdapter.KEY_ROWID + " = " + id, null);
	}
	
	public List<GiftCard> getAllGiftCards(){
		List<GiftCard> gcs = new ArrayList<GiftCard>();
		
		Cursor c = 	database.query(GiftCardDbAdapter.DATABASE_TABLE,allColumns, null,null,null,null,null);
		
		c.moveToFirst();
		
		while(c.isAfterLast()){
		GiftCard gc = getGiftCard(c);
		gcs.add(gc);
		c.moveToNext();
		}
		c.close();
		return gcs;
	}
	
	private GiftCard getGiftCard(Cursor c){
		GiftCard gc = new GiftCard(c);
		
		return gc;
	}
	
	public int getTotalEntries(){
		Cursor c = 	database.query(GiftCardDbAdapter.DATABASE_TABLE,allColumns, null,null,null,null,null);
		c.moveToLast();
		return c.getPosition();
	}
	
	public Cursor getCursor(){
		Cursor c = 	database.query(GiftCardDbAdapter.DATABASE_TABLE,allColumns, null,null,null,null,null);
		
		c.moveToFirst();
		return c;
	}
	
}

