package com.RebelliousDesign.GCW;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Simple notes database access helper class. Defines the basic CRUD operations
 * for the notepad example, and gives the ability to list all notes as well as
 * retrieve or modify a specific note.
 * 
 * This has been improved from the first version of this tutorial through the
 * addition of better error handling and also using returning a Cursor instead
 * of using a collection of inner classes (which is less scalable and not
 * recommended).
 */
public class GiftCardDbAdapter  extends SQLiteOpenHelper{
	public static final String[] allColumns = new String[] {GiftCardDbAdapter.KEY_ROWID,
		GiftCardDbAdapter.KEY_COMPANY, GiftCardDbAdapter.KEY_SERIAL,
		GiftCardDbAdapter.KEY_EXPIRY, GiftCardDbAdapter.KEY_PHONE,
		GiftCardDbAdapter.KEY_BALANCE, GiftCardDbAdapter.KEY_NOTES};
	
    public static final String KEY_COMPANY = "company";
    public static final String KEY_SERIAL = "serial";
	public static final String KEY_EXPIRY = "expiry";
	public static final String KEY_PHONE = "phone";
	public static final String KEY_BALANCE = "balance";
	public static final String KEY_NOTES = "notes";
	public static final String KEY_ROWID = "_id";

    private static final String TAG = "GiftCardDbAdapter";
    //private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    /**
     * Database creation sql statement
     */
    private static final String DATABASE_CREATE =
        "create table giftcards (_id integer primary key autoincrement, "
        + "company text not null, serial text not null, expiry text not null, phone text not null, balance text not null, notes text not null);";

    private static final String DATABASE_NAME = "giftcardsdb";
    public static final String DATABASE_TABLE = "giftcards";
    private static final int DATABASE_VERSION = 2;


    public GiftCardDbAdapter(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
        onCreate(db);
    }
    
}
