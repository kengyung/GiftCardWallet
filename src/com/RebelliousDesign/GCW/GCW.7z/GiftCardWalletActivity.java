package com.RebelliousDesign.GCW;


import android.app.Activity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;


import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.SimpleAdapter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;

import java.util.ArrayList;
import java.util.HashMap;

public class GiftCardWalletActivity extends ListActivity implements OnItemClickListener{
	
	ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String,String>>();
	private SimpleAdapter simpleList;
	private GiftCardDataSource gcDAO;
	Intent viewIntent = new Intent();
	final int RETURN_CODE = 1; //by default  not okay  
	final int OK = 0;
	final int NOTOK = 1;
	
	
	//Debug stuff

	TextView debugger;

	
	final int ADD_ITEM_ID = 1;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        gcDAO = new GiftCardDataSource(this);
        gcDAO.open();
        fillData();
        viewIntent.setClass(this, GiftCardAddEdit.class);
      
        //Old Stuff
       /* 
        simpleList = new SimpleAdapter( 
				this, 
				list,
				R.layout.main_items_two_line_row,
				new String[] { "companyName","balance" },
				new int[] { R.id.companyNameCol, R.id.balanceCol }  );
        
       setListAdapter( simpleList );

       */
        
        //End of old stuff
        
		String [] names = {"Aeropostale", "American Eagle", "Blockbuster","Canada Computers"};
		double [] balances = {27.19, 46.83, 55.34,102.32};
		
		for (int i=0;i<names.length;i++){
			//Old Stuff
			/*
		  HashMap<String,String> item = new HashMap<String,String>();
		  item.put( "companyName", names[i] );
		  item.put( "balance",Double.toString(balances[i]) );
		  list.add( item );
		  */
			//End of old stuff
			//gcDAO.createCard(names[i], "serial", "expiry", "phone", Double.toString(balances[i]), "notes");
		  
		}


		
	      //simpleList.notifyDataSetChanged();
		
	      //Debug stuff
	      debugger = (TextView) findViewById(R.id.android_debug);
	      //debugger.setOnTouchListener(this);
    
	 	 ListView lv = getListView();
		  lv.setTextFilterEnabled(true);

		  lv.setOnItemClickListener(new OnItemClickListener() {
		    public void onItemClick(AdapterView<?> parent, View view,
		        int position, long id) {
		    	debugger.setText("Item #:" + Integer.toString(position) + " was touched.");
		    	Toast.makeText(getApplicationContext(), "Item #:" + Integer.toString(position) + " was touched.", Toast.LENGTH_SHORT).show();
		    	//Delete gift card
		    	//gcDAO.deleteCard(id);    	
		    	//fillData();
		    	viewIntent.putExtra("id", id);
		    	startActivityForResult(viewIntent, RETURN_CODE);
		    	
		    }
		  });
    
    }
    
    public boolean onCreateOptionsMenu(Menu menu) {
    	
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(0, ADD_ITEM_ID, Menu.NONE, "Add item" );
        return result;
      }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch ( item.getItemId() ) {
          case ADD_ITEM_ID:
        	  addItem();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    
	private void addItem() {
		String [] names = {"Aeropostale", "American Eagle", "Blockbuster","Canada Computers"};
		double [] balances = {27.19, 46.83, 55.34,102.32};
		int position= gcDAO.getTotalEntries();
		GiftCard gc;
		for (int i=0;i<names.length;i++){
		  //old stuff
			/*
		  HashMap<String,String> item = new HashMap<String,String>();
		  item.put( "companyName", names[i] );
		  item.put( "balance",balances[i] );
		  list.add( item );
		  */
		  //end of old stuff
			gc = new GiftCard(names[i], "No", 0, balances[i], "Blank", "999-999-9999", position);
			//String company, String serial, int expiry, double balance, String notes, String phone, int id
			gcDAO.createGC(gc);
		}
		fillData();
		//list.remove(3);
	      //simpleList.notifyDataSetChanged();
	      
	    //Debug stuff
//	debugger.setText(Integer.toString(list.size()));
	      
	      
//	debugger.setText(list.get(1).get("companyName"));
		//list.get(1).get("companyName")
	      //list = list
	      //get(1) = get element # from array (hashtable)
	      //get("companyName") = get the value from the field "companyName" in the hash table
	}
	
	private void fillData(){
        //New Stuff
        
	    Cursor c = gcDAO.getCursor();
        startManagingCursor(c);

        String[] from = new String[] { GiftCardDbAdapter.KEY_COMPANY, GiftCardDbAdapter.KEY_BALANCE};//, GiftCardDbAdapter.KEY_EXPIRY,GiftCardDbAdapter.KEY_PHONE,GiftCardDbAdapter.KEY_BALANCE,GiftCardDbAdapter.KEY_NOTES };
        int[] to = new int[] { R.id.companyNameCol, R.id.balanceCol };
        
        // Now create an array adapter and set it to display using our row
        SimpleCursorAdapter cards =
            new SimpleCursorAdapter(this, R.layout.main_items_two_line_row, c, from, to);
        setListAdapter(cards);
        

        //End of New Stuff
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		

	}
	

    
    
}